package com.allan.loadexe;

import java.awt.FileDialog;
import java.awt.Frame;
import java.io.File;
import javax.swing.JFrame;

public class LoadEXE {

	public LoadEXE(){
		
	}
	/**
	 * 
	 * Where should I open the exe file in the interface?
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		  Frame frame =new JFrame();
//		String path = "LoadEXE.java";
//		  File file = new File(path);
//		  System.out.println(file.getAbsoluteFile());
//		FileDialog fileDlg =  new FileDialog(frame,"OTDR����λ��",FileDialog.LOAD);
//		fileDlg.setVisible(true);
//		String url = fileDlg.getDirectory();
//		String exeName = fileDlg.getFile();
//		System.out.println(url);
//		System.out.println(exeName);
		
		try {
			Runtime runTime = Runtime.getRuntime();
			//�ҵ����Ӧ�ľ���·��
			File myFile = new File("C:\\Documents and Settings\\yangl-006305\\����\\OTMx", "OTDR Module Client Software V2.1�����ģ�.exe");
			//�жϸ��ļ��Ƿ���exe����
			
			//File myFile = new File(url,exeName);
		 runTime.exec(myFile.getAbsolutePath());
		 System.out.println(myFile.getAbsolutePath());
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e); 
		}
	}

}
