
package com.allan.student;

/**
 * @author yangl-006305
 *
 */
public class StudentBean {

	public StudentBean() {
		// TODO Auto-generated constructor stub
	}
	private String studentName;
	private String password;
	private String address;
	private long id;
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
}
