package com.allan.java8.feature;

public class SimpleImpl  implements NewInterface{

	@Override
	public void getInfo() {
		// TODO Auto-generated method stub
		 System.out.println("INFO");
	        defaultMethod();
	}

}
