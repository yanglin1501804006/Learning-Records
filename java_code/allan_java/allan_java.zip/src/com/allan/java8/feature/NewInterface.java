package com.allan.java8.feature;

/**
 * https://blog.csdn.net/sun_promise/article/details/51220518  Java 8 �����ԣ��ӿ���ǿ
 * https://blog.csdn.net/BryantLmm/article/details/79156602
 * 
 * @author yangl-006305
 *
 */
public interface NewInterface {
	// Interfaces now allow static methods
	public static void staticMethod() {
		System.out.println("staticMethod");
	}

	public default void defaultMethod() {
		System.out.println("defaultMethod");
	}

	public abstract void getInfo();
	static final String allan = "we are happy" ;
	public String yanglin = "You are sad" ;
}
