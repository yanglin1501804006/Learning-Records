package com.allan.design.pattern.creational.builder;

public interface Packing {
    public String pack();
}
