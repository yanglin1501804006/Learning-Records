package com.allan.design.pattern.creational.factory;

public class Square implements Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
			System.out.println("Square: draw() method !");
			
	}

}
