package com.allan.design.pattern.behavioral.strategy;

public interface Strategy {
	public abstract int doOperation(int num1, int num2);
}
