package com.allan.design.pattern.behavioral.Iterator;

public interface Container {
    public Iterator getIterator();
}
