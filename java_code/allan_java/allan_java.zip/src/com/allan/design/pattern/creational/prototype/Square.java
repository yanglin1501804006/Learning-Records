package com.allan.design.pattern.creational.prototype;

public class Square extends Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println(" Square::draw() method.");
	}

	public Square() {
		// TODO Auto-generated constructor stub
		type = "Square" ;
	}
}
