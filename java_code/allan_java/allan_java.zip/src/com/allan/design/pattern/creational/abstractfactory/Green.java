package com.allan.design.pattern.creational.abstractfactory;

public class Green implements Color {

	@Override
	public void fill() {
		// TODO Auto-generated method stub
		 System.out.println("Green: fill()  method!");
	}

}
