package com.allan.design.pattern.creational.prototype;

public class Circle extends Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println(" Square::draw() method.");
	}

	public Circle() {
		// TODO Auto-generated constructor stub
		type = "Circle";
	}
}
