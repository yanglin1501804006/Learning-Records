package com.allan.design.pattern.creational.builder;

public class Coke extends ColdDrink {

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "Coke";
	}

	@Override
	public float price() {
		// TODO Auto-generated method stub
		return 3.0f;
	}

}
