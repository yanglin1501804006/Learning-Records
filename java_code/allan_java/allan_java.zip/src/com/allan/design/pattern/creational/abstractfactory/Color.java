package com.allan.design.pattern.creational.abstractfactory;

public interface Color {
	void fill();
}
