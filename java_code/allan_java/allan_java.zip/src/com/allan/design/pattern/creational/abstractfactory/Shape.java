package com.allan.design.pattern.creational.abstractfactory;

public interface Shape {
	void draw();
}
