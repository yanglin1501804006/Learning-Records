package com.allan.design.pattern.behavioral.Interpreter;

public interface Expression {
    public boolean interpret(String context);
}
