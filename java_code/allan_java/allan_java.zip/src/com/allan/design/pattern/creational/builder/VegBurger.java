package com.allan.design.pattern.creational.builder;

public class VegBurger extends Burger {

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "Vegburger" ;
	}

	@Override
	public float price() {
		// TODO Auto-generated method stub
		return 22.5f;
	}

}
