package com.allan.design.pattern.structural.proxy;

public interface Image {
	public  abstract void display();
}
