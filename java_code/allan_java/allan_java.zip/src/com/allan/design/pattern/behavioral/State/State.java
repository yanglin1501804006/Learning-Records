package com.allan.design.pattern.behavioral.State;


public interface State {
    public void doAction(Context context);
}

