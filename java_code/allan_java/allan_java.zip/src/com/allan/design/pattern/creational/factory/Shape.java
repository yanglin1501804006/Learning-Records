package com.allan.design.pattern.creational.factory;

public interface Shape {
	void draw();
}
