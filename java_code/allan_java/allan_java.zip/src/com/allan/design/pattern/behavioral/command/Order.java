package com.allan.design.pattern.behavioral.command;

public interface Order {

    public void execute();
}
