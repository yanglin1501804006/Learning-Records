package com.allan.design.pattern.creational.builder;

public class ChickenBurger extends Burger {

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "ChickenBurger";
	}

	@Override
	public float price() {
		// TODO Auto-generated method stub
		return 34.5f;
	}

}
