package com.allan.design.pattern.behavioral.Visitor;


public interface ComputerPart {
    public void accept(ComputerPartVisitor computerPartVisitor);
}
