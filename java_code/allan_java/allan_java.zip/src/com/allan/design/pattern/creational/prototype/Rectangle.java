package com.allan.design.pattern.creational.prototype;

public class Rectangle extends Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println(" Rectangle::draw() method.");
	}
	
	 public Rectangle(){
	     type = "Rectangle";
	   }

}
