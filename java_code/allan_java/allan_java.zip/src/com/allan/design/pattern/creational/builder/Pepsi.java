package com.allan.design.pattern.creational.builder;

public class Pepsi extends ColdDrink {

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "Pepsi";
	}

	@Override
	public float price() {
		// TODO Auto-generated method stub
		return 2.5f;
	}

}
