package com.allan.design.pattern.structural.facade;

public class Circle implements Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
			System.out.println("circle: draw() method !");
	}

}
