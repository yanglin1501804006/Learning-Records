package com.allan.design.pattern.structural.facade;

public interface Shape {
	void draw();
}
