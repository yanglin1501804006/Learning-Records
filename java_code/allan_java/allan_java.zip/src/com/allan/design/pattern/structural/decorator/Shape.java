package com.allan.design.pattern.structural.decorator;

public interface Shape {
	void draw();
}
