package com.allan.design.pattern.structural.flyweight;

public interface Shape {
	void draw();
}
