package com.allan.design.pattern.creational.abstractfactory;

public class Blue implements Color {

	@Override
	public void fill() {
		// TODO Auto-generated method stub
		 System.out.println("Blue: fill()  method!");
	}

}
