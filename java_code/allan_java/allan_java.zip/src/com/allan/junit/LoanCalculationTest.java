package com.allan.junit;

import java.util.Scanner;
import org.junit.Before;
import org.junit.Test;
import com.allan.loan.calculation.LoanCalculationUtil;

public class LoanCalculationTest {

	private Scanner input;

	@Before
	public void setUp() throws Exception {

	}

	@Test
	public void test() {
		input = new Scanner(System.in);
		System.out.println("please input the loan amount :");
		double principal = input.nextDouble();

		System.out.println("please input  months of loan :");
		int months = input.nextInt();

		System.out.println("please input the loan rate :");
		double rate = input.nextDouble();
		// �ȶ��ʽ
		LoanCalculationUtil.calculateEqualPrincipal(principal, months, rate);

		System.out.println();

		// �ȶϢ��ʽ
		LoanCalculationUtil.calculateEqualPrincipalAndInterest(principal, months, rate);

	}

}
