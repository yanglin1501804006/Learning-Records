package com.allan.annotation;


/**
 * https://www.cnblogs.com/acm-bingzi/p/javaAnnotation.html
 * @author yangl-006305
 *
 */
public class FruitRun {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			FruitInfoUtil.getFruitInfo(Apple.class);
	}

}
