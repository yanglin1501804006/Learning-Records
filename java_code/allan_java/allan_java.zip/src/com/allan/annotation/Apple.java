package com.allan.annotation;

import com.allan.annotation.FruitColor.Color;

/**
 * 
 * ע��ʹ��
 * 
 * @author yangl-006305
 *
 */
public class Apple {
	@FruitName("Apple")
	private String appleName;

	@FruitColor(fruitColor = Color.RED)
	private String appleColor;

	@FruitProvider(id = 1, name = "Raisecom", address = "�йش�����԰������11��Ժ")
	private String appleProvider;

	public String getAppleName() {
		return appleName;
	}

	public void setAppleName(String appleName) {
		this.appleName = appleName;
	}

	public String getAppleColor() {
		return appleColor;
	}

	public void setAppleColor(String appleColor) {
		this.appleColor = appleColor;
	}

	public String getAppleProvider() {
		return appleProvider;
	}

	public void setAppleProvider(String appleProvider) {
		this.appleProvider = appleProvider;
	}

	public void displayName() {
		System.out.println("ˮ���������ǣ�ƻ��");
	}

}
