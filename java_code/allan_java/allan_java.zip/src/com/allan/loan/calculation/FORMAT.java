package com.allan.loan.calculation;

import java.text.DecimalFormat;

public class FORMAT {

	public static String format(double totalMoney) {
		// TODO Auto-generated method stub
		DecimalFormat df = new DecimalFormat("#.00"); 
		return df.format(totalMoney) ;
	}

}
