package com.allan.loan.calculation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class LoopArray {

	public static void main(String[] args) {  
        List<String> al = new ArrayList<String>();  
        al.add("wangw1");  
        al.add("wangw3");  
        al.add("wangw4");  
        al.add("wangw5");  
          
        //������ʽ1  
        Iterator<String> it1 = al.iterator();  
        while(it1.hasNext()){  
            System.out.println(it1.next());  
        }  
          
        //������ʽ2  
        for(Iterator<String> it2 = al.iterator();it2.hasNext();){  
            System.out.println(it2.next());  
        }  
          
        //������ʽ3  
        for(String temp:al){  
            System.out.println(temp);  
        }  
          
        //������ʽ4  
        for(int i = 0;i<al.size();i++){  
            System.out.println(al.get(i));  
        }  
    }  
}
