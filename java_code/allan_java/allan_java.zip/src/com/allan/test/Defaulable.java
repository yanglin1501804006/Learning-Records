package com.allan.test;

public class Defaulable {
		public static void main(String[] args) {
		}
}
