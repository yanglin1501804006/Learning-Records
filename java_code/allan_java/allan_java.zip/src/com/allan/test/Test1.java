package com.allan.test;

import java.util.Hashtable;

//import sun.management.counter.LongCounter;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a1 = "YANGLIN";
		//String a1 = "yanglin";
		String a2 = "yanglin";
	 if (a1.contains(a2)) {
		System.out.println("succeed!");
	} else {
		System.out.println("failed!");
	}
	 
		int a3= 5 ;
		int a4 = 10;
		System.out.println("a3/a4 = " + (a3/a4));
	 
		Double a5= (double) 5 ;
		Double a6 = (double) 10;
		System.out.println("a3/a4 = " + (a5/a6));
	long ssm1 = Long.parseLong("000c0003", 16);
	
	System.out.println(ssm1);
		//int ssm = Integer.parseInt("000c003");
	//	System.out.println(ssm);
		
	
	}
	

}
