package com.allan.test;

public class TestJava {

	public static void main(String[] args) {

		//�ַ���������
		String testString = "abc" ;
		testString = testString.concat("cd");
		System.out.println(testString);
		
		
	}

}
