package com.allan.test;

/**
 * Alibaba.class
 * 
 * @author yangl-006305
 * @date 2017/11/16
 */
public class Alibaba {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String channelPortNo = "16";
		int splitNo = 16;
		int slot = Integer.parseInt(channelPortNo) / splitNo + 3 - 1;
		System.out.println(slot);

		int j = 0;
		for (int i = 0; i < 100; i++) {
			// j=j++ ;
			j = ++j;
			// System.out.println(j);
		}
		System.out.println(j);

		System.out.println("#############");

		int a = 3;
		int b = 2;
		long d = (long) Math.pow(a, b);
		System.out.println("d = " + d);
		
		System.out.println("ר������һ��sonar�Ĵ���");
		boolean c = true ;
		if (c) {
			System.out.println("");
		} else {
			System.out.println("");
		}

	}

}
