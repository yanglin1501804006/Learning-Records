package com.allan.test;

import java.math.BigDecimal;

public class TestNumber {

	public static void main(String[] args) {
		float a = 16777216.0f;
		float b = 1.0f;
		float c = a + b; 
		System.out.println("c = " + c);
		
		double d = a + b;
		System.out.println("d = " + d);
		
		System.out.println("@@@@@@@@@@@@@@@@@");
		
		float a1 = 16777216.0f;
		float b1= 1.0f;
		BigDecimal c1 = BigDecimal.valueOf(a1).add(BigDecimal.valueOf(b1));
		System.out.println("c1 =" + c1);
		double d1 = (double)a1 + (double)b1;
		System.out.println("d1 =" + d1);
		System.out.println("@@@@@@@@@@@@@@@@@");
		
		int a2 = 3 ;
		String a3 = "-2a" ;
		int a4 = Integer.parseInt(a3+"");
		
		double a5 = a4 ;
		System.out.println("a5 = " + a5);
		
		
	}

}
