package com.allan.test;

public class SDHGroupRoadPlateSwitchAdapter {

	public SDHGroupRoadPlateSwitchAdapter() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
