package com.allan.test;

import com.allan.java8.feature.NewInterface;

public class TestInterface implements NewInterface {

	@Override
	public void getInfo() {
		// TODO Auto-generated method stub
		//System.out.println("This is a method!");
	}

	public static void main(String[] args) {
		TestInterface testInterface = new TestInterface();
		testInterface.defaultMethod();
		
		NewInterface.staticMethod();
		
		String a = "&lt;" ;
		System.out.println(a);
		
	}
}
