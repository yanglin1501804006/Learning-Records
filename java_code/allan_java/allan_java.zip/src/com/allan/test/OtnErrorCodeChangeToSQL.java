package com.allan.test;

import java.awt.FileDialog;
import java.awt.Frame;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import javax.swing.JFrame;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class OtnErrorCodeChangeToSQL {
	String erren;
	StringBuilder s11;
	StringBuilder s12;

	public static void main(String[] args) {
		OtnErrorCodeChangeToSQL test2 = new OtnErrorCodeChangeToSQL();
		Frame frame = new JFrame();
		FileDialog fileDialog = new FileDialog(frame, "���ش�����ģ��", FileDialog.LOAD);
		fileDialog.setFile("*.xlsx");
		fileDialog.setVisible(true);
		String dir = fileDialog.getDirectory();
		String pathName = fileDialog.getFile();
		String absolutePath = dir + pathName ;
		File file = new File(absolutePath);
		test2.readCodeSortExcel(file);
	}

	/**
	 * ���Ƕ�ȡ����Excel�ķ��������������Been����
	 * 
	 * @param excel
	 * @return
	 * @throws Exception
	 */
	private void readCodeSortExcel(File excel) {
		InputStream ins;
		try {
			ins = new FileInputStream(excel);
			Workbook workBook = WorkbookFactory.create(ins);
			Sheet sheet = workBook.getSheetAt(0);
			Row row = null;
			// �õ����Y����
			int coordinateY = sheet.getPhysicalNumberOfRows();
			for (int y = 1; y < coordinateY; y++) {
				s11 = new StringBuilder();
				s12 = new StringBuilder();
				row = sheet.getRow(y);
				Cell errcode1 = row.getCell(2);
				String errcode = errcode1.toString();
				errcode = errcode.replaceAll("0x", "otn_");
				// errcode=errcode+"000000";
				// ��ȡӢ�ķ��������
				Cell errdescen = row.getCell(3);
				//��ȡ���ķ��������
				Cell errdescch = row.getCell(4);
				erren = errdescen.toString();
				if (!"".equals(erren) && erren.contains("'")) {
					erren = erren.replaceAll("'", "");
				}

				s12.append("delete from otn_error_desc where error_code= '");
				s12.append(errcode);
				s12.append("';");
				System.out.println(s12.toString());
				s11.append(
						"INSERT INTO `otn_error_desc` (`ERROR_CODE`, `ERROR_DESC`, `ERROR_DESC_CH`, `ERROR_DESC_EN`) VALUES ('");
				s11.append(errcode);
				s11.append("', '");
				s11.append(errdescch);
				s11.append("', '");
				s11.append(errdescch);
				s11.append("', '");
				s11.append(erren);
				s11.append("');");
				System.out.println(s11.toString());
			}

		} catch (Exception e1) {
			Thread.currentThread().interrupt();
		}
	}
}
