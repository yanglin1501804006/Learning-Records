package com.allan.test;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 //String hex = "4f5343";
		String hex = null;
		// char c = (char)Integer.parseInt(hex.substring(0, 2), 16);
		// System.out.println(c);
		
		  Integer a =  100;
		  Integer b =  100;
		  System.out.println( a == b);
		  Integer c =  1000;
		  Integer d =  1000;
		  System.out.println( c == d);
		
		 if ("4f5343".equalsIgnoreCase(hex)) {
			System.out.println("test1 result is true,  not have an exception.");
		} 
		 //һ�㲻����д��ԭ���� ��������hex��ǰ��Ϊnullʱ�򣬻��׳�һ����ָ���쳣
		  if(hex.equalsIgnoreCase("4f5343")){
			 System.out.println("test2 result is true, have an exception.");
		}
		  
	
	}

}
