package com.allan.test;

import java.text.SimpleDateFormat;
import java.util.Date;
//import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;
public class Teat {

	public static void main(String[] args) throws  java.text.ParseException {
		// TODO Auto-generated method stub
		 float a = 78_9.8f ;
		int b = (int)a;
		System.out.println(b);
		String small = "��������%s��ʽ";
		String result  = String.format("%s", small);
		System.out.println(result);
		String allan = "yanglin";
		String c = allan.replace("a", "\\.");
		String d = allan.replace('a', 'n');
		String e = allan.replaceAll("a", "\\.");
		String f = allan.replaceAll("a", ".");
		String h = allan.replaceAll("a", "/.");
		System.out.println(c + "\n" +d+"\n" + e+"\n" +f+"\n" +h);
		
//		String curruntTime = DateFormat.getDateInstance().format(new Date());
//		System.out.println(curruntTime);
		
		 	String string = "2014-63-17";
	        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	        Date date = null;
	        try {
	            date = dateFormat.parse(string);
	        System.out.println("stringdate is " + date.toLocaleString().split(" ")[0]);//�и����Ҫ��ʱ��������
	        } catch (Exception e1) {
	            e1.printStackTrace();
	        }
	        System.out.println( "date =" + date );
		
		
		Date date1 = new Date(2018-1900,6,28);
		Date date2 = new Date(2018,12,30);
		System.out.println((date2.getTime()-date1.getTime())/(1000*3600*24));
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		System.out.println(sdf.format(date1));
		
		String str = "2018-07-28";
		
		int a1 =10;
		int a2=90;
		boolean a3=a1>1&&a1+81<a2;
		if (a3) {
			System.out.println("result = " + a3);
		}else {
			System.out.println("result is " + a3);
		}
		if("".length() >=2*1){
			System.out.println("succeed!");
		}
		
		
	}

	

}
